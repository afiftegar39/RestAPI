import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';
import '../models/models.dart';

class ApiService {
  // Get token dari SharedPreferences
  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // Save token
  Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
  }

  // Remove token
  Future<void> _removeToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  // Headers dengan token
  Future<Map<String, String>> _getHeaders() async {
    final token = await _getToken();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // ==================== AUTH ====================
  Future<Map<String, dynamic>> register(String name, String email, String password) async {
    try {
      print('🔵 Attempting to register: $email');
      print('🔵 URL: ${ApiConfig.register}');
      
      final response = await http.post(
        Uri.parse(ApiConfig.register),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json', // PENTING untuk Laravel!
        },
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      print('🔵 Status Code: ${response.statusCode}');
      print('🔵 Response Body: ${response.body}');

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 201 && data['success']) {
        await _saveToken(data['data']['token']);
        return {'success': true, 'user': User.fromJson(data['data']['user'])};
      }
      
      return {'success': false, 'message': data['message'] ?? 'Registration failed'};
    } catch (e) {
      print('🔴 Error: $e');
      return {'success': false, 'message': 'Connection error: $e'};
    }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      print('🔵 Attempting to login: $email');
      
      final response = await http.post(
        Uri.parse(ApiConfig.login),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json', // PENTING untuk Laravel!
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      );

      print('🔵 Status Code: ${response.statusCode}');
      print('🔵 Response Body: ${response.body}');

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success']) {
        await _saveToken(data['data']['token']);
        return {'success': true, 'user': User.fromJson(data['data']['user'])};
      }
      
      return {'success': false, 'message': data['message'] ?? 'Login failed'};
    } catch (e) {
      print('🔴 Error: $e');
      return {'success': false, 'message': 'Connection error: $e'};
    }
  }

  Future<bool> logout() async {
    try {
      final headers = await _getHeaders();
      final response = await http.post(
        Uri.parse(ApiConfig.logout),
        headers: headers,
      );

      await _removeToken();
      return response.statusCode == 200;
    } catch (e) {
      await _removeToken();
      return false;
    }
  }

  Future<User?> getCurrentUser() async {
    try {
      final headers = await _getHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.user),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return User.fromJson(data['data']);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ==================== NEWS ====================
  Future<List<News>> getNews() async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.news),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          return (data['data'] as List).map((n) => News.fromJson(n)).toList();
        }
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  Future<News?> getNewsDetail(int id) async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.newsDetail(id)),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          return News.fromJson(data['data']);
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ==================== COMMENTS ====================
  Future<List<Comment>> getComments(int newsId) async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.comments(newsId)),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          return (data['data'] as List).map((c) => Comment.fromJson(c)).toList();
        }
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  Future<Map<String, dynamic>> addComment(int newsId, String comment) async {
    try {
      final headers = await _getHeaders();
      final response = await http.post(
        Uri.parse(ApiConfig.addComment(newsId)),
        headers: headers,
        body: jsonEncode({'comment': comment}),
      );

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 201 && data['success']) {
        return {'success': true, 'comment': Comment.fromJson(data['data'])};
      }
      
      return {'success': false, 'message': data['message'] ?? 'Failed to add comment'};
    } catch (e) {
      return {'success': false, 'message': 'Connection error: $e'};
    }
  }

  // Check if user is logged in
  Future<bool> isLoggedIn() async {
    final token = await _getToken();
    return token != null;
  }
}