// lib/config/api_config.dart
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;

class ApiConfig {
  // Default base path (will be overridden by getBaseUrl())
  static String get baseUrl {
    // If running on web (Chrome / Edge) use 127.0.0.1
    if (kIsWeb) {
      return 'http://127.0.0.1:8000/api';
    }

    // Android emulator (default Android Studio emulator) -> 10.0.2.2
    if (Platform.isAndroid) {
      return 'http://10.0.2.2:8000/api';
    }

    // iOS simulator
    if (Platform.isIOS) {
      return 'http://127.0.0.1:8000/api';
    }

    // Desktop / others (uses loopback)
    return 'http://127.0.0.1:8000/api';
  }

  static String get imageUrl {
    // same host but without /api
    final host = baseUrl.replaceFirst('/api', '');
    return '$host/storage';
  }

  // Auth endpoints
  static String get register => '$baseUrl/register';
  static String get login => '$baseUrl/login';
  static String get logout => '$baseUrl/logout';
  static String get user => '$baseUrl/user';

  // News endpoints
  static String get news => '$baseUrl/news';
  static String newsDetail(int id) => '$baseUrl/news/$id';
  static String newsByCategory(String category) => '$baseUrl/news/category/$category';

  // Comment endpoints
  static String comments(int newsId) => '$baseUrl/news/$newsId/comments';
  static String addComment(int newsId) => '$baseUrl/news/$newsId/comments';

  // Helper untuk gambar
  static String getImageUrl(String? path) {
    if (path == null || path.isEmpty) return '';
    if (path.startsWith('http')) return path;
    return '$imageUrl/$path';
  }
}
