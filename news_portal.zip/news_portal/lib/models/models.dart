// User Model
class User {
  final int id;
  final String name;
  final String email;
  final String? createdAt;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      createdAt: json['created_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'created_at': createdAt,
    };
  }
}

// Comment Model
class Comment {
  final int id;
  final int userId;
  final int newsId;
  final String comment;
  final String createdAt;
  final User? user;

  Comment({
    required this.id,
    required this.userId,
    required this.newsId,
    required this.comment,
    required this.createdAt,
    this.user,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'] ?? 0,
      userId: json['user_id'] ?? 0,
      newsId: json['news_id'] ?? 0,
      comment: json['comment'] ?? '',
      createdAt: json['created_at'] ?? '',
      user: json['user'] != null ? User.fromJson(json['user']) : null,
    );
  }
}

// News Model
class News {
  final int id;
  final int userId;
  final String title;
  final String content;
  final String category;
  final String? image;
  final int views;
  final String createdAt;
  final User? user;
  final List<Comment>? comments;

  News({
    required this.id,
    required this.userId,
    required this.title,
    required this.content,
    required this.category,
    this.image,
    required this.views,
    required this.createdAt,
    this.user,
    this.comments,
  });

  factory News.fromJson(Map<String, dynamic> json) {
    return News(
      id: json['id'] ?? 0,
      userId: json['user_id'] ?? 0,
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      category: json['category'] ?? '',
      image: json['image'],
      views: json['views'] ?? 0,
      createdAt: json['created_at'] ?? '',
      user: json['user'] != null ? User.fromJson(json['user']) : null,
      comments: json['comments'] != null
          ? (json['comments'] as List).map((c) => Comment.fromJson(c)).toList()
          : null,
    );
  }
}