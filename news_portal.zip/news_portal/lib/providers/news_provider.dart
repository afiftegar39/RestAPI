import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class NewsProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  List<News> _newsList = [];
  List<Comment> _comments = [];

  bool _isLoadingNews = false;
  bool _isLoadingComments = false;
  bool _isSendingComment = false;

  News? _selectedNews;

  List<News> get newsList => _newsList;
  List<Comment> get comments => _comments;

  bool get isLoadingNews => _isLoadingNews;
  bool get isLoadingComments => _isLoadingComments;
  bool get isSendingComment => _isSendingComment;

  News? get selectedNews => _selectedNews;

  // Fetch All News
  Future<void> fetchNews() async {
    _isLoadingNews = true;
    notifyListeners();

    _newsList = await _apiService.getNews();

    _isLoadingNews = false;
    notifyListeners();
  }

  // Load News Detail + Comments
  Future<void> loadNewsDetail(int newsId) async {
    _isLoadingNews = true;
    _isLoadingComments = true;
    notifyListeners();

    final news = await _apiService.getNewsDetail(newsId);
    final comments = await _apiService.getComments(newsId);

    _selectedNews = news;
    _comments = comments;

    _isLoadingNews = false;
    _isLoadingComments = false;
    notifyListeners();
  }

  // Send Comment
  Future<bool> sendComment(int newsId, String comment) async {
    _isSendingComment = true;
    notifyListeners();

    final result = await _apiService.addComment(newsId, comment);

    _isSendingComment = false;

    if (result['success'] == true) {
      // Tambahkan komentar baru ke list
      _comments.insert(0, result['comment']);
      notifyListeners();
      return true;
    }

    notifyListeners();
    return false;
  }
}
